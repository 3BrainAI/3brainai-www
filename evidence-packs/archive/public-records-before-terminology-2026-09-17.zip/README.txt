Original public record sources before the terminology revision of 17 September 2026.
Snapshot from commit fc256261c14ae6c51937349cc67ad71ae4baa84a.
Contains original HTML sources, the original Fischamend v0.1 PDF and its evidence images.
SHA256.json also lists the referenced website assets, which remain unchanged at https://www.3brain.ai/.
Other referenced assets are not duplicated in this source archive.
The current public routes carry terminology revisions.
